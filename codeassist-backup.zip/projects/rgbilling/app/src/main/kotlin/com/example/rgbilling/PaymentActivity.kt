package com.example.rgbilling

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PaymentActivity : Activity() {

    private lateinit var txtTotal: TextView
    private lateinit var txtKembali: TextView
    private lateinit var edtBayar: EditText
    private lateinit var btnHitung: Button
    private lateinit var btnSelesai: Button

    private lateinit var db: DatabaseHelper

    private var index = 0
    private var totalBayar = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payment)

        db = DatabaseHelper(this)

        txtTotal = findViewById(R.id.txtTotal)
        txtKembali = findViewById(R.id.txtKembali)
        edtBayar = findViewById(R.id.edtBayar)
        btnHitung = findViewById(R.id.btnHitung)
        btnSelesai = findViewById(R.id.btnSelesai)

        index = intent.getIntExtra("PS_INDEX", 0)

        totalBayar = PsData.biaya[index] + PsData.biayaKantin[index]

        txtTotal.text =
            "Main : ${MoneyUtils.rupiah(PsData.biaya[index])}\n" +
            "Kantin : ${MoneyUtils.rupiah(PsData.biayaKantin[index])}\n\n" +
            "TOTAL : ${MoneyUtils.rupiah(totalBayar)}"

        txtKembali.text = MoneyUtils.rupiah(0)

        btnHitung.setOnClickListener {

            val bayar = edtBayar.text.toString().toIntOrNull() ?: 0

            if (bayar < totalBayar) {

                txtKembali.text = "Uang Kurang!"

            } else {

                val kembali = bayar - totalBayar

                txtKembali.text = MoneyUtils.rupiah(kembali)

                PsData.uangBayar[index] = bayar
                PsData.kembalian[index] = kembali
            }
        }

        btnSelesai.setOnClickListener {

            if (PsData.uangBayar[index] < totalBayar) {

                Toast.makeText(
                    this,
                    "Pembayaran belum cukup!",
                    Toast.LENGTH_SHORT
                ).show()

                return@setOnClickListener
            }

            val tanggal = SimpleDateFormat(
                "dd-MM-yyyy HH:mm",
                Locale.getDefault()
            ).format(Date())

            db.simpan(
                tanggal,
                "PS ${index + 1}",
                PsData.namaPelanggan[index],
                PsData.detik[index],
                totalBayar
            )

            PsData.selesai(index)

            Toast.makeText(
                this,
                "Transaksi berhasil disimpan",
                Toast.LENGTH_SHORT
            ).show()

            val intent = Intent(this, MainActivity::class.java)
            intent.addFlags(
                Intent.FLAG_ACTIVITY_CLEAR_TOP or
                        Intent.FLAG_ACTIVITY_SINGLE_TOP
            )

            startActivity(intent)
            finish()
        }
    }
}