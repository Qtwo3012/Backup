package com.example.rgbilling

import android.content.Context

object SettingsManager {

    private const val PREF = "RG_BILLING"
    private const val KEY_TARIF = "TARIF"

    fun getTarif(context: Context): Int {

        val pref = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)

        return pref.getInt(KEY_TARIF, 10000)

    }

    fun setTarif(
        context: Context,
        tarif: Int
    ) {

        val pref = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)

        pref.edit()
            .putInt(KEY_TARIF, tarif)
            .apply()

    }

}