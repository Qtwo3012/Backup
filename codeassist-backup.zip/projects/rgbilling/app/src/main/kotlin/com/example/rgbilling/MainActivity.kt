package com.example.rgbilling

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.os.Handler
import android.os.Looper
import java.text.SimpleDateFormat
import java.util.*


class MainActivity : Activity() {

    private lateinit var txtPendapatan: TextView
    private lateinit var txtPendapatanPs: TextView
    private lateinit var txtPendapatanKantin: TextView
    private lateinit var txtProdukTerlaris: TextView
    private lateinit var txtStokTipis: TextView
    private lateinit var txtTransaksi: TextView
    private lateinit var txtPsAktif: TextView

    private lateinit var btnPs1: Button
    private lateinit var btnPs2: Button
    private lateinit var btnPs3: Button
    private lateinit var btnPs4: Button

    private lateinit var btnKantin: Button
    private lateinit var btnProduk: Button
    private lateinit var btnHistory: Button
    private lateinit var btnRiwayatKantin: Button
    private lateinit var btnSettings: Button

    private lateinit var db: DatabaseHelper
    
    private lateinit var txtJam: TextView

    private val handler = Handler(Looper.getMainLooper())
    private val CHANNEL_ID = "rg_billing_channel"

    private val jamRunnable = object : Runnable {
        override fun run() {
            val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
            txtJam.text = "🕒 " + sdf.format(Date())
            handler.postDelayed(this, 1000)
        }
    }
    
    private val dashboardRunnable = object : Runnable {
        override fun run() {

            for (i in PsData.berjalan.indices) {

                if (PsData.berjalan[i]) {
                    PsData.hitung(i)
                }

            }

            refreshDashboard()

            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = DatabaseHelper(this)

        db.isiProdukDefault()

        txtPendapatan = findViewById(R.id.txtPendapatan)
        txtPendapatanPs = findViewById(R.id.txtPendapatanPs)
        txtPendapatanKantin = findViewById(R.id.txtPendapatanKantin)
        txtProdukTerlaris = findViewById(R.id.txtProdukTerlaris)
        txtStokTipis = findViewById(R.id.txtStokTipis)
        txtTransaksi = findViewById(R.id.txtTransaksi)
        txtPsAktif = findViewById(R.id.txtPsAktif)

        btnPs1 = findViewById(R.id.btnPs1)
        btnPs2 = findViewById(R.id.btnPs2)
        btnPs3 = findViewById(R.id.btnPs3)
        btnPs4 = findViewById(R.id.btnPs4)

        btnKantin = findViewById(R.id.btnKantin)
        btnProduk = findViewById(R.id.btnProduk)
        btnHistory = findViewById(R.id.btnHistory)
        btnRiwayatKantin = findViewById(R.id.btnRiwayatKantin)
        btnSettings = findViewById(R.id.btnSettings)

        btnPs1.setOnClickListener {
            bukaPs(0, "PS 1")
        }

        btnPs2.setOnClickListener {
            bukaPs(1, "PS 2")
        }

        btnPs3.setOnClickListener {
            bukaPs(2, "PS 3")
        }

        btnPs4.setOnClickListener {
            bukaPs(3, "PS 4")
        }

        btnKantin.setOnClickListener {
            startActivity(
                Intent(this, KantinActivity::class.java)
            )
        }

        btnProduk.setOnClickListener {
            startActivity(
                Intent(this, ProdukActivity::class.java)
            )
        }

        btnHistory.setOnClickListener {
            startActivity(
                Intent(this, HistoryActivity::class.java)
            )
        }
        
        btnRiwayatKantin.setOnClickListener {
            startActivity(
                Intent(this, RiwayatKantinActivity::class.java)
            )
        }

        btnSettings.setOnClickListener {
            startActivity(
                Intent(this, SettingsActivity::class.java)
            )
        }
    }

    override fun onResume() {
        super.onResume()

        PsData.tarifPerJam =
            SettingsManager.getTarif(this)

        handler.removeCallbacks(dashboardRunnable)
        handler.post(dashboardRunnable)
    }
    
    override fun onPause() {
        super.onPause()

        handler.removeCallbacks(dashboardRunnable)
    }
    
        private fun refreshDashboard() {

        txtPendapatan.text =
            "💰 Total Omzet : ${
                MoneyUtils.rupiah(
                    db.getOmzetTotal()
                )
            }"

        txtPendapatanPs.text =
            "🎮 Pendapatan PS : ${
                MoneyUtils.rupiah(
                    db.getPendapatanPS()
                )
            }"

        txtPendapatanKantin.text =
            "🍜 Pendapatan Kantin : ${
                MoneyUtils.rupiah(
                    db.getPendapatanKantin()
                )
            }"

        txtProdukTerlaris.text =
            "🏆 Produk Terlaris : ${
                db.getProdukTerlaris()
            }"

        txtStokTipis.text =
            "⚠️ Stok Menipis : ${
                db.getJumlahStokMenipis()
            }"
        txtTransaksi.text =
            "📄 Transaksi : ${db.getJumlahTransaksi()}"

        var aktif = 0

        for (i in PsData.berjalan.indices) {
            if (PsData.berjalan[i]) aktif++
        }

        txtPsAktif.text =
            "🎮 PS Aktif : $aktif / ${PsData.berjalan.size}"

        updateButton(btnPs1, 0, "PS 1")
        updateButton(btnPs2, 1, "PS 2")
        updateButton(btnPs3, 2, "PS 3")
        updateButton(btnPs4, 3, "PS 4")
    }

        private fun updateButton(
            button: Button,
            index: Int,
            nama: String
        ) {

            if (PsData.berjalan[index]) {

                val namaTampil =
                    if (PsData.namaPelanggan[index].isBlank())
                        "-"
                    else
                        PsData.namaPelanggan[index]

                val billing =
                    if (PsData.modeBilling[index] == "PAKET")
                        "🟨 ${PsData.paketJam[index]} JAM"
                    else
                        "🟦 LOS"

                val jamMain =
                    if (PsData.modeBilling[index] == "PAKET")
                        "🕒 ${PsData.jamMulai[index]} - ${PsData.jamSelesai[index]}"
                    else
                        "🕒 ${PsData.jamMulai[index]}"

                val timer =
                    if (PsData.modeBilling[index] == "PAKET") {

                        val jam = PsData.sisaDetik[index] / 3600
                        val menit = (PsData.sisaDetik[index] % 3600) / 60
                        val detik = PsData.sisaDetik[index] % 60

                        "⏳ " + String.format(
                            "%02d:%02d:%02d",
                            jam,
                            menit,
                            detik
                        )

                    } else {

                        val jam = PsData.detik[index] / 3600
                        val menit = (PsData.detik[index] % 3600) / 60
                        val detik = PsData.detik[index] % 60

                        "⏱ " + String.format(
                            "%02d:%02d:%02d",
                            jam,
                            menit,
                            detik
                        )

                    }

                val biaya =
                    if (PsData.modeBilling[index] == "PAKET")
                        MoneyUtils.rupiah(
                            PsData.paketJam[index] * PsData.tarifPerJam
                        )
                    else
                        MoneyUtils.rupiah(
                            PsData.biaya[index]
                        )

                // ==========================
                // WARNA CARD
                // ==========================

                if (PsData.modeBilling[index] == "PAKET") {

                    if (PsData.sisaDetik[index] <= 0) {

                        button.setBackgroundResource(
                            R.drawable.card_ps_habis
                        )

                    } else if (PsData.sisaDetik[index] <= 300) {

                        button.setBackgroundResource(
                            R.drawable.card_ps_warning
                        )

                    } else {

                        button.setBackgroundResource(
                            R.drawable.card_ps_playing
                        )

                    }

                } else {

                    button.setBackgroundResource(
                        R.drawable.card_ps_playing
                    )

                }

                button.textSize = 13f
                button.setTextColor(android.graphics.Color.WHITE)

                val statusInfo =
                    if (PsData.modeBilling[index] == "PAKET") {

                        when {

                            PsData.sisaDetik[index] <= 0 ->
                                "⛔ WAKTU HABIS"

                            PsData.sisaDetik[index] <= 60 ->
                                "🚨 1 MENIT LAGI"

                            PsData.sisaDetik[index] <= 300 ->
                                "⚠️ 5 MENIT LAGI"

                            else ->
                                "🎮 BERMAIN"

                        }

                    } else {

                        "🎮 BERMAIN"

                    }

                button.text =
                    "🔴 $nama\n\n" +
                    "$statusInfo\n" +
                    "👤 $namaTampil\n" +
                    "$billing\n" +
                    "$jamMain\n" +
                    "$timer\n" +
                    "💰 $biaya"

            } else {

                button.setBackgroundResource(
                    R.drawable.card_ps_ready
                )

                button.textSize = 15f
                button.setTextColor(android.graphics.Color.WHITE)

                button.text =
                    "🟢 $nama\n\n" +
                    "🎮 READY"

            }
        }
    private fun bukaPs(
        index: Int,
        nama: String
    ) {

        val intent = Intent(this, PsActivity::class.java)

        intent.putExtra("PS_INDEX", index)
        intent.putExtra("PS_NAME", nama)

        startActivity(intent)
    }
    
    }