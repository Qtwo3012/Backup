package com.example.rgbilling

data class CartItem(
    val produk: Produk,
    var qty: Int = 0
)