package com.example.rgbilling

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.media.MediaPlayer
import android.media.AudioManager
import android.media.ToneGenerator

class PsActivity : Activity() {

    private lateinit var txtJamMulai: TextView
    private lateinit var txtJamSelesai: TextView
    private lateinit var txtNamaPs: TextView
    private lateinit var txtStatus: TextView
    private lateinit var txtTimer: TextView
    private lateinit var txtBiaya: TextView
    private lateinit var spPaket: Spinner
    private lateinit var edtNama: EditText

    private lateinit var btnStart: Button
    private lateinit var btnStop: Button
    private lateinit var btnBayar: Button
    
    private lateinit var btnTambah1: Button
    private lateinit var btnTambah2: Button
    private lateinit var btnTambah3: Button

    private var index = 0

    private val handler = Handler(Looper.getMainLooper())
    
    private var alarmSudahBunyi = false
    private val tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100)

    private val timer = object : Runnable {
        override fun run() {
            PsData.hitung(index)

            tampil()

            if (PsData.berjalan[index]) {
                handler.postDelayed(this, 1000)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ps)

        txtNamaPs = findViewById(R.id.txtNamaPs)
        txtStatus = findViewById(R.id.txtStatus)
        txtTimer = findViewById(R.id.txtTimer)
        txtBiaya = findViewById(R.id.txtBiaya)
        txtJamMulai = findViewById(R.id.txtJamMulai)
        txtJamSelesai = findViewById(R.id.txtJamSelesai)

        edtNama = findViewById(R.id.edtNama)
        spPaket = findViewById(R.id.spPaket)

        val daftarPaket = arrayOf(
            "REGULER",
            "1 JAM - Rp10.000",
            "2 JAM - Rp20.000",
            "3 JAM - Rp30.000",
            "4 JAM - Rp40.000",
            "5 JAM - Rp50.000",
            "6 JAM - Rp60.000"
        )

        spPaket.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            daftarPaket
        )

        btnStart = findViewById(R.id.btnStart)
        btnStop = findViewById(R.id.btnStop)
        btnBayar = findViewById(R.id.btnBayar)

        btnTambah1 = findViewById(R.id.btnTambah1)
        btnTambah2 = findViewById(R.id.btnTambah2)
        btnTambah3 = findViewById(R.id.btnTambah3)
       
        btnTambah1.setOnClickListener {

            if (PsData.modeBilling[index] == "PAKET") {
                PsData.tambahPaket(index, 1)
                tampil()
            }
        }

        btnTambah2.setOnClickListener {

            if (PsData.modeBilling[index] == "PAKET") {
                PsData.tambahPaket(index, 2)
                tampil()
            }
        }

        btnTambah3.setOnClickListener {

            if (PsData.modeBilling[index] == "PAKET") {
                PsData.tambahPaket(index, 3)
                tampil()
            }
        }
              
        index = intent.getIntExtra("PS_INDEX", 0)

        txtNamaPs.text = intent.getStringExtra("PS_NAME")

        edtNama.setText(PsData.namaPelanggan[index])

        tampil()

        if (PsData.berjalan[index]) {
            handler.post(timer)
        }

        btnStart.setOnClickListener {

            PsData.namaPelanggan[index] = edtNama.text.toString()
            when (spPaket.selectedItemPosition) {

                0 -> {
                    PsData.modeBilling[index] = "REGULER"
                    PsData.mulai(index)
                }

                else -> {
                    PsData.modeBilling[index] = "PAKET"
                    PsData.mulaiPaket(index, spPaket.selectedItemPosition)
                }
            }

            handler.removeCallbacks(timer)
            handler.post(timer)

            tampil()
        }

        btnStop.setOnClickListener {

            PsData.berhenti(index)

            handler.removeCallbacks(timer)

            tampil()
        }

        btnBayar.setOnClickListener {

            val intent = Intent(this, PaymentActivity::class.java)
            intent.putExtra("PS_INDEX", index)

            startActivity(intent)
        }
    }

    private fun tampil() {

        val sedangMain = PsData.berjalan[index]

        txtStatus.text =
            when {
                sedangMain -> "🔴 BERMAIN"
                PsData.modeBilling[index] == "PAKET" &&
                        PsData.sisaDetik[index] == 0 &&
                        PsData.paketDetik[index] > 0 ->
                    "🟠 SELESAI"
                else ->
                    "🟢 READY"
            }

        if (PsData.modeBilling[index] == "PAKET") {

            val jam = PsData.sisaDetik[index] / 3600
            val menit = (PsData.sisaDetik[index] % 3600) / 60
            val detik = PsData.sisaDetik[index] % 60

            txtTimer.text =
                String.format("%02d:%02d:%02d", jam, menit, detik)

        } else {

            val jam = PsData.detik[index] / 3600
            val menit = (PsData.detik[index] % 3600) / 60
            val detik = PsData.detik[index] % 60

            txtTimer.text =
                String.format("%02d:%02d:%02d", jam, menit, detik)
        }

        val total =
            PsData.biaya[index] +
                    PsData.biayaKantin[index]

        txtBiaya.text =
            MoneyUtils.rupiah(total)

        txtJamMulai.text =
            "🕒 Mulai : ${PsData.jamMulai[index]}"

        txtJamSelesai.text =
            "🏁 Selesai : ${PsData.jamSelesai[index]}"

        // Tombol
        val selesaiBelumBayar =
            !sedangMain &&
            PsData.modeBilling[index] == "PAKET" &&
            PsData.paketDetik[index] > 0 &&
            PsData.sisaDetik[index] == 0

        btnStart.isEnabled =
            !sedangMain && !selesaiBelumBayar

        btnStop.isEnabled = sedangMain

        btnBayar.isEnabled =
            !sedangMain &&
                    total > 0

        val aktifTambah =
            sedangMain &&
                    PsData.modeBilling[index] == "PAKET"

        btnTambah1.isEnabled = aktifTambah
        btnTambah2.isEnabled = aktifTambah
        btnTambah3.isEnabled = aktifTambah
        
        if (!alarmSudahBunyi &&
            !PsData.berjalan[index] &&
            PsData.modeBilling[index] == "PAKET" &&
            PsData.sisaDetik[index] == 0 &&
            PsData.paketDetik[index] > 0) {

            alarmSudahBunyi = true

        tone.startTone(
            ToneGenerator.TONE_PROP_BEEP,
            600
        )
        }

        if (PsData.berjalan[index]) {
            alarmSudahBunyi = false
        }
        
    }
    
    override fun onResume() {
        super.onResume()
        tampil()
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(timer)
        tone.release()
    }
}