package com.example.rgbilling

data class Produk(
    val nama: String,
    val harga: Int,
    val stok: Int
)