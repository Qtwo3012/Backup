package com.example.rgbilling

object TimeUtils {

    fun format(detik: Int): String {

        val jam = detik / 3600
        val menit = (detik % 3600) / 60
        val dtk = detik % 60

        return String.format("%02d:%02d:%02d", jam, menit, dtk)
    }

}