package com.example.rgbilling

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class EditProdukActivity : Activity() {

    private lateinit var edtNama: EditText
    private lateinit var edtKategori: EditText
    private lateinit var edtModal: EditText
    private lateinit var edtJual: EditText
    private lateinit var edtStok: EditText
    private lateinit var btnUpdate: Button

    private lateinit var db: DatabaseHelper

    private var namaLama = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_produk)

        db = DatabaseHelper(this)

        edtNama = findViewById(R.id.edtNama)
        edtKategori = findViewById(R.id.edtKategori)
        edtModal = findViewById(R.id.edtModal)
        edtJual = findViewById(R.id.edtJual)
        edtStok = findViewById(R.id.edtStok)
        btnUpdate = findViewById(R.id.btnUpdate)

        namaLama = intent.getStringExtra("nama") ?: ""

        val produk = db.getProduk(namaLama)

        if (produk != null) {

            edtNama.setText(produk.nama)
            edtJual.setText(produk.harga.toString())
            edtStok.setText(produk.stok.toString())

        }

        btnUpdate.setOnClickListener {

            db.updateProduk(
                namaLama,
                edtNama.text.toString(),
                edtKategori.text.toString(),
                edtModal.text.toString().toIntOrNull() ?: 0,
                edtJual.text.toString().toIntOrNull() ?: 0,
                edtStok.text.toString().toIntOrNull() ?: 0
            )

            Toast.makeText(
                this,
                "Produk berhasil diupdate",
                Toast.LENGTH_SHORT
            ).show()

            setResult(RESULT_OK)

            finish()

        }

    }

}