package com.example.rgbilling

enum class PsMode {

    FREE_PLAY,

    MENIT_30,

    JAM_1,

    JAM_2,

    JAM_3

}