package com.example.rgbilling

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class SettingsActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val edtTarif = findViewById<EditText>(R.id.edtTarif)

        val btnSimpan = findViewById<Button>(R.id.btnSimpan)
        val btnProdukDefault = findViewById<Button>(R.id.btnProdukDefault)
        val btnBackup = findViewById<Button>(R.id.btnBackup)
        val btnRestore = findViewById<Button>(R.id.btnRestore)

        edtTarif.setText(
            SettingsManager.getTarif(this).toString()
        )

        btnSimpan.setOnClickListener {

            val tarif =
                edtTarif.text.toString().toIntOrNull() ?: 10000

            SettingsManager.setTarif(this, tarif)
            PsData.tarifPerJam = tarif

            Toast.makeText(
                this,
                "✅ Tarif berhasil disimpan",
                Toast.LENGTH_SHORT
            ).show()

        }

        btnProdukDefault.setOnClickListener {

            AlertDialog.Builder(this)
                .setTitle("Produk Default")
                .setMessage("Cek dan tambahkan produk default yang belum ada?")
                .setPositiveButton("YA") { _, _ ->

                    DatabaseHelper(this).isiProdukDefault()

                    Toast.makeText(
                        this,
                        "✅ Produk default berhasil dicek.",
                        Toast.LENGTH_SHORT
                    ).show()

                }
                .setNegativeButton("Batal", null)
                .show()

        }

        btnBackup.setOnClickListener {

            Toast.makeText(
                this,
                "🚧 Backup database masih tahap pengembangan",
                Toast.LENGTH_SHORT
            ).show()

        }

        btnRestore.setOnClickListener {

            Toast.makeText(
                this,
                "🚧 Restore database masih tahap pengembangan",
                Toast.LENGTH_SHORT
            ).show()

        }

    }

}