package com.example.rgbilling

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class HistoryActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        val txtHistory = findViewById<TextView>(R.id.txtHistory)

        val db = DatabaseHelper(this)

        val database = db.readableDatabase

        val cursor = database.rawQuery(
            "SELECT * FROM transaksi ORDER BY id DESC",
            null
        )

        val hasil = StringBuilder()

        var jumlah = 0
        var totalPendapatan = 0

        while (cursor.moveToNext()) {

            jumlah++
            totalPendapatan += cursor.getInt(5)

            hasil.append("━━━━━━━━━━━━━━━━━━━━\n")
            hasil.append("🧾 Transaksi #")
            hasil.append(jumlah)
            hasil.append("\n\n")

            hasil.append("📅 ")
            hasil.append(cursor.getString(1))
            hasil.append("\n")

            hasil.append("🎮 ")
            hasil.append(cursor.getString(2))
            hasil.append("\n")

            hasil.append("👤 ")
            hasil.append(cursor.getString(3))
            hasil.append("\n")

            hasil.append("⏱ ")
            hasil.append(cursor.getInt(4))
            hasil.append(" detik\n")

            hasil.append("💰 ")
            hasil.append(
                MoneyUtils.rupiah(
                    cursor.getInt(5)
                )
            )

            hasil.append("\n\n")

        }

        cursor.close()

        val header = StringBuilder()

        header.append("📊 RINGKASAN\n")
        header.append("━━━━━━━━━━━━━━━━━━━━\n")
        header.append("📄 Total Transaksi : ")
        header.append(jumlah)
        header.append("\n")

        header.append("💰 Total Pendapatan\n")
        header.append(MoneyUtils.rupiah(totalPendapatan))
        header.append("\n\n")

        txtHistory.text = header.toString() + hasil.toString()

    }

}