package com.example.rgbilling

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class CartAdapter(
    context: Context,
    private val data: MutableList<CartItem>,
    private val onChanged: () -> Unit
) : ArrayAdapter<CartItem>(context, 0, data) {

    override fun getView(
        position: Int,
        convertView: View?,
        parent: ViewGroup
    ): View {

        val view = convertView ?: LayoutInflater.from(context)
            .inflate(R.layout.item_cart, parent, false)

        val txtNama = view.findViewById<TextView>(R.id.txtNama)
        val txtHarga = view.findViewById<TextView>(R.id.txtHarga)
        val txtSubtotal = view.findViewById<TextView>(R.id.txtSubtotal)
        val txtQty = view.findViewById<TextView>(R.id.txtQty)
        val btnMinus = view.findViewById<Button>(R.id.btnMinus)
        val btnPlus = view.findViewById<Button>(R.id.btnPlus)

        val item = data[position]

        if (item.produk.stok <= 0) {
            txtNama.text = "❌ ${item.produk.nama}\nSTOK HABIS"
            btnPlus.isEnabled = false
        } else {
            txtNama.text = "${item.produk.nama}\nStok : ${item.produk.stok}"
            btnPlus.isEnabled = true
        }

        txtHarga.text = MoneyUtils.rupiah(item.produk.harga)
        txtQty.text = item.qty.toString()

        txtSubtotal.text =
            "Subtotal : " + MoneyUtils.rupiah(item.qty * item.produk.harga)

        btnPlus.setOnClickListener {

            if (item.produk.stok <= 0) {
                Toast.makeText(
                    context,
                    "Produk habis",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            if (item.qty < item.produk.stok) {

                item.qty++

                txtQty.text = item.qty.toString()

                txtSubtotal.text =
                    "Subtotal : " + MoneyUtils.rupiah(item.qty * item.produk.harga)

                onChanged()

            } else {

                Toast.makeText(
                    context,
                    "Stok tidak mencukupi",
                    Toast.LENGTH_SHORT
                ).show()

            }
        }

        btnMinus.setOnClickListener {

            if (item.qty > 0) {

                item.qty--

                txtQty.text = item.qty.toString()

                txtSubtotal.text =
                    "Subtotal : " + MoneyUtils.rupiah(item.qty * item.produk.harga)

                onChanged()

            }
        }

        return view
    }
}