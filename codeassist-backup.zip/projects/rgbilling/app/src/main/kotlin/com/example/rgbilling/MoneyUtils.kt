package com.example.rgbilling

import java.text.NumberFormat
import java.util.Locale

object MoneyUtils {

    private val rupiahFormat =
        NumberFormat.getCurrencyInstance(
            Locale("id", "ID")
        ).apply {
            maximumFractionDigits = 0
        }

    fun rupiah(nominal: Int): String {
        return rupiahFormat.format(nominal)
    }

    fun rupiah(nominal: Long): String {
        return rupiahFormat.format(nominal)
    }

    fun rupiah(nominal: Double): String {
        return rupiahFormat.format(nominal)
    }

}