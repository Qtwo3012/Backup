package com.example.rgbilling

import android.app.Activity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class TambahProdukActivity : Activity() {

    private lateinit var edtNama: EditText
    private lateinit var edtKategori: EditText
    private lateinit var edtModal: EditText
    private lateinit var edtJual: EditText
    private lateinit var edtStok: EditText
    private lateinit var btnSimpan: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tambah_produk)

        edtNama = findViewById(R.id.edtNama)
        edtKategori = findViewById(R.id.edtKategori)
        edtModal = findViewById(R.id.edtModal)
        edtJual = findViewById(R.id.edtJual)
        edtStok = findViewById(R.id.edtStok)

        btnSimpan = findViewById(R.id.btnSimpan)

        btnSimpan.setOnClickListener {

            val nama = edtNama.text.toString().trim()
            val kategori = edtKategori.text.toString().trim()

            val modal = edtModal.text.toString().toIntOrNull() ?: 0
            val jual = edtJual.text.toString().toIntOrNull() ?: 0
            val stok = edtStok.text.toString().toIntOrNull() ?: 0

            if (nama.isEmpty()) {
                edtNama.error = "Nama produk wajib diisi"
                return@setOnClickListener
            }

            val db = DatabaseHelper(this)

            db.tambahProduk(
                nama,
                kategori,
                modal,
                jual,
                stok
            )

            Toast.makeText(
                this,
                "Produk berhasil disimpan",
                Toast.LENGTH_SHORT
            ).show()

            finish()
        }
    }
}