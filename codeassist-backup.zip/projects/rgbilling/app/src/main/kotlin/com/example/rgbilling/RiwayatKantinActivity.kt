package com.example.rgbilling

import android.app.Activity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView

class RiwayatKantinActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_riwayat_kantin)

        val list = findViewById<ListView>(R.id.listRiwayat)

        val db = DatabaseHelper(this)

        val data = db.getRiwayatKantin()

        list.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,
            data
        )

    }

}