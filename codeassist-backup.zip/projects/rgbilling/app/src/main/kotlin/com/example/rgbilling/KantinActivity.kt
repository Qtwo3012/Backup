package com.example.rgbilling

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ListView
import android.widget.TextView

class KantinActivity : Activity() {

    private lateinit var listProduk: ListView
    private lateinit var txtTotal: TextView
    private lateinit var btnSimpan: Button
    private lateinit var btnStruk: Button

    private lateinit var db: DatabaseHelper
    private lateinit var adapter: CartAdapter

    private val cart = mutableListOf<CartItem>()

    private var strukTerakhir = "Belum ada transaksi"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_kantin)

        listProduk = findViewById(R.id.listProduk)
        txtTotal = findViewById(R.id.txtTotal)
        btnSimpan = findViewById(R.id.btnSimpan)
        btnStruk = findViewById(R.id.btnStruk)

        db = DatabaseHelper(this)

        loadProduk()

        adapter = CartAdapter(
            this,
            cart
        ) {
            hitungTotal()
        }

        listProduk.adapter = adapter

        btnStruk.setOnClickListener {

            val i = Intent(
                this,
                StrukActivity::class.java
            )

            i.putExtra(
                "STRUK",
                strukTerakhir
            )

            startActivity(i)

        }

        btnSimpan.setOnClickListener {

            var total = 0

            val sb = StringBuilder()

            sb.append("===== RG BILLING PRO =====\n\n")

            cart.forEach { item ->

                if (item.qty > 0) {

                    val subtotal = item.qty * item.produk.harga

                    total += subtotal

                    sb.append(
                        "${item.produk.nama}\n" +
                        "${item.qty} x ${MoneyUtils.rupiah(item.produk.harga)} = ${MoneyUtils.rupiah(subtotal)}\n\n"
                    )

                    db.simpanTransaksiKantin(
                        System.currentTimeMillis().toString(),
                        item.produk.nama,
                        item.qty,
                        item.produk.harga,
                        subtotal
                    )

                    db.kurangiStok(
                        item.produk.nama,
                        item.qty
                    )

                }

            }

            sb.append("-------------------------\n")
            sb.append("TOTAL : ${MoneyUtils.rupiah(total)}")

            strukTerakhir = sb.toString()

            cart.clear()

            loadProduk()

            adapter.notifyDataSetChanged()

            hitungTotal()

            val hasil = Intent()

            hasil.putExtra(
                "TOTAL_KANTIN",
                total
            )

            setResult(
                RESULT_OK,
                hasil
            )

        }

    }

    private fun loadProduk() {

        cart.clear()

        db.getSemuaProduk().forEach {

            cart.add(
                CartItem(it)
            )

        }

    }

    private fun hitungTotal() {

        var total = 0

        cart.forEach {

            total += it.qty * it.produk.harga

        }

        txtTotal.text =
            "TOTAL : ${MoneyUtils.rupiah(total)}"

    }

}