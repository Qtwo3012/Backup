package com.example.rgbilling

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class StrukActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val txt = TextView(this)
        txt.textSize = 16f
        txt.setPadding(24, 24, 24, 24)

        txt.text = intent.getStringExtra("STRUK") ?: "Belum ada struk"

        setContentView(txt)
    }
}