package com.example.rgbilling

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView

class ProdukActivity : Activity() {

    private lateinit var listProduk: ListView
    private lateinit var btnTambah: Button
    private lateinit var db: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_produk)

        db = DatabaseHelper(this)

        listProduk = findViewById(R.id.listProduk)
        btnTambah = findViewById(R.id.btnTambah)

        btnTambah.setOnClickListener {
            startActivity(
                Intent(this, TambahProdukActivity::class.java)
            )
        }
    }

    override fun onResume() {
        super.onResume()

        val data = db.getSemuaProduk()

        val daftar = ArrayList<String>()

        for (p in data) {
            daftar.add("${p.nama} | Rp ${p.harga} | Stok ${p.stok}")
        }

        listProduk.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,
            daftar
        )

        listProduk.setOnItemClickListener { _, _, position, _ ->

            AlertDialog.Builder(this)
                .setTitle(data[position].nama)
                .setItems(
                    arrayOf(
                        "✏ Edit",
                        "🗑 Hapus"
                    )
                ) { _, which ->

                    when (which) {

                        0 -> {
                            try {
                                val i = Intent(
                                    this,
                                    EditProdukActivity::class.java
                                )

                                i.putExtra(
                                    "nama",
                                    data[position].nama
                                )

                                startActivity(i)

                            } catch (_: Exception) {
                            }
                        }

                        1 -> {

                            db.hapusProduk(
                                data[position].nama
                            )

                            onResume()
                        }
                    }
                }
                .show()
        }
    }
}